# Useful Download Links

[Azure CLI Download Page](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-windows?view=azure-cli-latest)

[PowerShell Core 7 Installation Page](https://docs.microsoft.com/en-us/powershell/scripting/install/installing-powershell-core-on-windows?view=powershell-7)

[Azure Data Migration Assistant Download Page](https://www.microsoft.com/download/details.aspx?id=53595)

[Demo Source on ArcaneCode GitHub site](https://github.com/arcanecode/Introduction-to-the-Azure-Data-Migration-Service)
