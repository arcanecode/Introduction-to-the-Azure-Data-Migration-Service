# Login Credentials

For easy reference, here are the login credentials for the demo server

Login:    student
Password: SecureP@ssW0rd
